#Countdown
def Countdown(n):
    if(n==-1):
        print("done")
    else:
        print(n)
        Countdown(n-1)

Countdown(5)

#Print and Return
def print_and_return():
        print(1)
        return(2)
variable = print_and_return()

print(int(variable))

#First Plus Length
def first_plus(i):
    i = [1,2,3,4,5]
    total = len(i)+1
    print(total)

first_plus(1)

#Values Greater than Second
def values_greater(list):
    list = [1,2,3]
    newList = [1]
    if len(list) > 5:
        return False
    else:
        list.append(1)

values_greater(1)

#This Length, That Value

def length_value(size,value):
    newList = []
    for i in range(size):
        newList.append(value)
    return newList

print(length_value(2,4))